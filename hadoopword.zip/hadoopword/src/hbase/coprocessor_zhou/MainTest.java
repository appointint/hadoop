package hbase.coprocessor_zhou;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainTest {

	public static void main(String[] args) {
		String reals="200038";
		String real=reals.substring(4,6)+"2000";
      System.out.println(real);
        }
      

	}

