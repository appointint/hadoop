package hbase.endpoint;

import org.apache.hadoop.hbase.util.Bytes;
/**
 * 常量设置
 * @author Administrator
 *
 */
public class Const
{
	public static final byte[] m_tFamily = Bytes.toBytes("userinfo");

}