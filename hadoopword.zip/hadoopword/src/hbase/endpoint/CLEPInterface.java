//package hbase.endpoint;
//
//import java.io.IOException;
//import java.util.Map;
//
//import org.apache.hadoop.hbase.ipc.CoprocessorProtocol;
//
//public interface CLEPInterface extends CoprocessorProtocol
//{
//	public Map<Integer, Long> queryNumByTime() throws IOException;
//	public Map<Integer, String> queryParam() throws IOException;
//}
