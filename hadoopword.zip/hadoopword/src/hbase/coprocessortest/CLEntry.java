package hbase.coprocessortest;

public class CLEntry {
	
	
	public static final String TUNAME="user";
	public static final String TUFAMILY="userinfo";
	public static final String TUCOLUMN_N="name";
	public static final String TUCOLUMN_A="age";
	public static final String TUCOLUMN_P="productid";
	
	public static final  String TPNAME="product";
	public static final String TPFAMILY="productinfo";
	public static final String TPCOLUMN_NA="name";
	public static final String TPCOLUMN_NUM="number";
	
	public static final String T_SPLIT=";";
	

}
