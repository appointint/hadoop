package hbase.tablemore;

public class User_Book_CreatePut {

}
